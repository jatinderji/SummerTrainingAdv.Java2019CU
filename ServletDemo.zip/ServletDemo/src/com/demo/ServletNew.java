package com.demo;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.demo.MyConnection;


public class ServletNew extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private RequestDispatcher rd;
	PrintWriter out=null;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		out= response.getWriter();
		rd = null;
		Cookie c[]= request.getCookies();
	
		System.out.println(c);
		
		ServletContext config = getServletContext();
		final String back = config.getInitParameter("backColor");

	for (int i = 0; i < c.length; i++) {
		Cookie cok = c[i];
		out.println("<p>"+cok.getName()+": "+cok.getValue()+"</p>");
	}
		
		if(c!=null)
		{
			String un = c[0].getValue();
			response.setContentType("text/html");
			out.println("<a style='background-color:"+back+"'>Welcome "+un+"</a>");
		}
		else
			response.sendRedirect("Login.html");

		/*		
		String n = request.getParameter("un");
		String p = request.getParameter("up");
		
		boolean result = false;
		try {
			result = MyConnection.isValidUser(n,p);
		}
		catch (SQLException | ClassNotFoundException e) {e.printStackTrace();}
		
		if(result)
		{
			rd = request.getRequestDispatcher("Welcome.html");
			rd.forward(request, response);
		}
		else
		{
			rd = request.getRequestDispatcher("Login.html");
			response.getWriter().write("<b style='color:red'>Invalid Username or Password");
			rd.include(request, response);
		}
*/
		
		
	}
}
