package com.demo;

import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import java.sql.Connection;

public class MyConnection
{

	public static boolean isValidUser(String em,String pass) throws SQLException, ClassNotFoundException
	{
	// username'OR 1=1'	
		Class.forName("com.mysql.jdbc.Driver");
Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/jvdb","root","1234");
PreparedStatement pst = con.prepareStatement("select * from users where email=? AND pass=?");
		
		pst.setString(1, em);
		pst.setString(2, pass);
	
		ResultSet rs = pst.executeQuery();
			if(rs.next())
			{
			con.close();
			return true;
			}
			else
			{
			con.close();
			return false;
			}
	}

}
