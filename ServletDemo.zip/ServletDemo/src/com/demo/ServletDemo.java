package com.demo;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.demo.MyConnection;


public class ServletDemo extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private RequestDispatcher rd;
	PrintWriter out=null;

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		out= response.getWriter();
		rd = null;
		
		String uname = request.getParameter("un");

		Cookie cookie = new Cookie("uname", uname);
		response.addCookie(cookie);
		
		response.setContentType("text/html");
		out.println("<center><h1>Welcome Page</h1><center>");
		out.println("<center><h4>Welcome "+uname+"</h4><center>");
		out.println("<a href='ServletNew'>Gallary</a>");
		out.println("</form>");
/*		
		String n = request.getParameter("un");
		String p = request.getParameter("up");
		
		boolean result = false;
		try {
			result = MyConnection.isValidUser(n,p);
		}
		catch (SQLException | ClassNotFoundException e) {e.printStackTrace();}
		
		if(result)
		{
			rd = request.getRequestDispatcher("Welcome.html");
			rd.forward(request, response);
		}
		else
		{
			rd = request.getRequestDispatcher("Login.html");
			response.getWriter().write("<b style='color:red'>Invalid Username or Password");
			rd.include(request, response);
		}
*/
		
		
	}
}
